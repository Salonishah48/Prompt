@echo off
title Smart Accountants - Timesheet Dashboard
color 1F
echo.
echo  ============================================================
echo    Smart Accountants - Timesheet Dashboard Generator v2
echo  ============================================================
echo.
echo  Place your Time and Expense Excel file in this folder,
echo  then press any key to generate the dashboard.
echo.
echo  TIP: Also add your "All employee details" sheet to the
echo       same Excel file to enable the Missing Time Entries tab
echo       with Emp ID, Department, and Manager information.
echo.
pause

cd /d "%~dp0"
python app.py

if %errorlevel% neq 0 (
    echo.
    echo  Something went wrong. Make sure you ran install_once.bat first.
    echo.
    pause
)
